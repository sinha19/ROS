from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([

        Node(package='turtlesim', executable='turtlesim_node', name='sim'),

        Node(package='turtle_tf2_py', executable='turtle_tf2_broadcaster',
             name='tf2_broadcaster_turtle1',
             parameters=[{'turtlename': 'turtle1'}]),

        Node(package='turtle_tf2_py', executable='turtle_tf2_broadcaster',
             name='tf2_broadcaster_turtle2',
             parameters=[{'turtlename': 'turtle2'}]),

        Node(package='turtle_tf2_py', executable='turtle_tf2_broadcaster',
             name='tf2_broadcaster_turtle3',
             parameters=[{'turtlename': 'turtle3'}]),

        Node(package='turtle_party', executable='follow',
             name='follow_turtle2',
             parameters=[{'target_frame': 'turtle1', 'turtle_name': 'turtle2'}]),

        Node(package='turtle_party', executable='follow',
             name='follow_turtle3',
             parameters=[{'target_frame': 'turtle2', 'turtle_name': 'turtle3'}]),
    ])
