import math
import rclpy
from rclpy.node import Node
from tf2_ros import TransformListener, Buffer
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn

class FollowTurtle(Node):
    def __init__(self):
        super().__init__('follow')

        # ROS parameters
        self.declare_parameter('target_frame', 'turtle1')
        self.declare_parameter('turtle_name', 'turtle2')
        self.target_frame = self.get_parameter('target_frame').value
        self.turtle_name  = self.get_parameter('turtle_name').value

        # TF2 listener
        self.tf_buffer   = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Velocity publisher for this turtle
        self.pub = self.create_publisher(
            Twist, f'/{self.turtle_name}/cmd_vel', 1)

        # Spawn this turtle
        self.spawner = self.create_client(Spawn, '/spawn')
        while not self.spawner.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for /spawn service...')
        req = Spawn.Request()
        req.x, req.y, req.theta, req.name = 4.0, 4.0, 0.0, self.turtle_name
        self.spawner.call_async(req)

        # Control loop 10Hz
        self.timer = self.create_timer(0.1, self.on_timer)

    def on_timer(self):
        try:
            t = self.tf_buffer.lookup_transform(
                self.turtle_name,
                self.target_frame,
                rclpy.time.Time())
        except Exception:
            return

        msg = Twist()
        msg.angular.z = 4.0 * math.atan2(
            t.transform.translation.y,
            t.transform.translation.x)
        msg.linear.x  = 0.5 * math.sqrt(
            t.transform.translation.x ** 2 +
            t.transform.translation.y ** 2)
        self.pub.publish(msg)

def main():
    rclpy.init()
    rclpy.spin(FollowTurtle())
    rclpy.shutdown()
