#!/usr/bin/env python3
"""
Assignment 6 - Task 1: Collision Avoidance
The robot moves forward. If an obstacle is detected ahead,
it turns on the spot until it is safe to move forward again.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


# Minimum safe distance in meters
SAFE_DISTANCE = 0.5

# Speed values
LINEAR_SPEED  = 0.2   # forward speed (m/s)
ANGULAR_SPEED = 0.5   # turning speed (rad/s)


class CollisionAvoider(Node):

    def __init__(self):
        super().__init__('collision_avoider')

        # Subscribe to laser scan
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        # Publish velocity commands
        self.cmd_pub = self.create_publisher(
            Twist,
            '/cmd_vel_unstamped',
            10
        )

        self.obstacle_ahead = False
        self.get_logger().info('Collision Avoider Node started.')

    def scan_callback(self, msg):
        """
        Check the front-facing laser readings.
        Front = indices around the middle of the ranges array (index 0 for
        forward-facing LiDAR, or a small window around index 0).
        """
        ranges = msg.ranges
        num_readings = len(ranges)

        # Take a 30-degree window in front: 15 degrees left and right of 0
        front_angle_indices = list(range(0, 15)) + list(range(num_readings - 15, num_readings))

        # Filter out invalid readings (inf, nan, 0)
        front_ranges = [
            ranges[i] for i in front_angle_indices
            if ranges[i] > 0.01 and not (ranges[i] == float('inf'))
        ]

        if front_ranges:
            min_front_distance = min(front_ranges)
        else:
            min_front_distance = float('inf')

        self.get_logger().info(f'Min front distance: {min_front_distance:.2f} m')

        cmd = Twist()

        if min_front_distance < SAFE_DISTANCE:
            # Obstacle detected — turn in place
            self.obstacle_ahead = True
            cmd.linear.x  = 0.0
            cmd.angular.z = ANGULAR_SPEED
            self.get_logger().info('Obstacle detected! Turning...')
        else:
            # Path is clear — move forward
            self.obstacle_ahead = False
            cmd.linear.x  = LINEAR_SPEED
            cmd.angular.z = 0.0
            self.get_logger().info('Path clear. Moving forward.')

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = CollisionAvoider()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the robot before exiting
        stop_cmd = Twist()
        node.cmd_pub.publish(stop_cmd)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
