#!/usr/bin/env python3
"""
Assignment 6 - Task 2: Wall Following
The robot follows the right wall at a fixed distance.
It uses the right-side laser readings to maintain a constant
distance from the wall while moving forward.
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


# Desired distance to keep from the right wall (meters)
DESIRED_WALL_DISTANCE = 0.4

# Speed values
LINEAR_SPEED  = 0.2   # forward speed (m/s)
MAX_ANGULAR   = 0.5   # max turning speed (rad/s)

# Distance threshold to detect a wall ahead (for corner handling)
FRONT_SAFE_DISTANCE = 0.5

# Proportional gain for wall distance error correction
KP = 1.5


class WallFollower(Node):

    def __init__(self):
        super().__init__('wall_follower')

        # Subscribe to laser scan
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )

        # Publish velocity commands
        self.cmd_pub = self.create_publisher(
            Twist,
            '/cmd_vel_unstamped',
            10
        )

        self.get_logger().info('Wall Follower Node started.')

    def get_range(self, ranges, angle_index):
        """Safely get a range value, returning inf for invalid readings."""
        val = ranges[angle_index]
        if val == 0.0 or val == float('inf') or val != val:  # nan check
            return float('inf')
        return val

    def scan_callback(self, msg):
        """
        Use laser scan to follow the right wall.

        Laser index convention (360-degree LiDAR):
          - Index 0   : directly in front
          - Index 90  : directly to the left
          - Index 270 : directly to the right
        """
        ranges = msg.ranges
        num   = len(ranges)

        # Front reading (obstacle detection)
        front_indices = list(range(0, 20)) + list(range(num - 20, num))
        front_ranges  = [
            ranges[i] for i in front_indices
            if ranges[i] > 0.01 and ranges[i] != float('inf')
        ]
        front_dist = min(front_ranges) if front_ranges else float('inf')

        # Right wall reading (~270 degrees = 3/4 of the array)
        right_index = int(num * 3 / 4)  # 270 degrees
        right_dist  = self.get_range(ranges, right_index)

        # Front-right reading (~315 degrees) for smoother cornering
        front_right_index = int(num * 7 / 8)
        front_right_dist  = self.get_range(ranges, front_right_index)

        self.get_logger().info(
            f'Front: {front_dist:.2f}m | Right: {right_dist:.2f}m | '
            f'Front-Right: {front_right_dist:.2f}m'
        )

        cmd = Twist()

        if front_dist < FRONT_SAFE_DISTANCE:
            # Wall ahead — turn left to avoid it
            cmd.linear.x  = 0.0
            cmd.angular.z = MAX_ANGULAR
            self.get_logger().info('Wall ahead! Turning left.')

        elif right_dist == float('inf'):
            # No wall on the right — turn right to find the wall
            cmd.linear.x  = LINEAR_SPEED
            cmd.angular.z = -MAX_ANGULAR / 2
            self.get_logger().info('No wall on right. Turning right to find wall.')

        else:
            # Wall detected on the right — use proportional control
            # to maintain DESIRED_WALL_DISTANCE
            error = DESIRED_WALL_DISTANCE - right_dist

            # Positive error  → too far from wall → turn right (negative z)
            # Negative error  → too close to wall → turn left (positive z)
            angular_correction = KP * error

            # Clamp angular speed
            angular_correction = max(-MAX_ANGULAR, min(MAX_ANGULAR, angular_correction))

            cmd.linear.x  = LINEAR_SPEED
            cmd.angular.z = -angular_correction  # negative: turn right to approach wall

            self.get_logger().info(
                f'Following wall. Error: {error:.2f}m | '
                f'Angular: {cmd.angular.z:.2f} rad/s'
            )

        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = WallFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Stop the robot before exiting
        stop_cmd = Twist()
        node.cmd_pub.publish(stop_cmd)
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
